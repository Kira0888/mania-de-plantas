# Mania de Plantas

Site de marca da **Mania de Plantas** — Floricultura & Garden Center.
Next.js 16 (App Router) · React 19 · Tailwind CSS 4 · Framer Motion 14 · TypeScript.

> Direção de marca completa (estratégia, paleta, tipografia, fotografia, arquitetura, prompts de imagem):
> **[docs/DIRECAO-DE-MARCA.md](docs/DIRECAO-DE-MARCA.md)**

## Rodar

```bash
npm install
npm run dev        # http://localhost:3000
npm run build && npm start   # produção (página 100% estática)
npm run typecheck && npm run lint
```

Em produção, defina o domínio final (canonical, sitemap, dados estruturados):

```bash
NEXT_PUBLIC_SITE_URL=https://seudominio.com.br
```

## Onde mexer

| Quero… | Arquivo |
|---|---|
| Trocar qualquer texto, número de WhatsApp, endereço, horário, Instagram, link do Google | [src/content/site.ts](src/content/site.ts) |
| Colocar avaliações **reais** | [src/content/reviews.ts](src/content/reviews.ts) |
| Colocar fotos | salvar em `public/images/` (ver abaixo) |
| Mudar cores / tipografia / escala | [src/app/globals.css](src/app/globals.css) (`@theme`) |
| Ajustar as seções | [src/components/sections/](src/components/sections/) |

### Fotos reais (zero código)
Salve o arquivo em `public/images/` com o nome da tabela abaixo (`.jpg`, `.jpeg`, `.png`, `.webp` ou `.avif`) e rebuilde. Enquanto o arquivo não existe, o site mostra uma **placa botânica ilustrada** no lugar — em `npm run dev`, a legenda dessa placa diz qual arquivo falta.

| Arquivo | Proporção | Onde aparece |
|---|---|---|
| `hero-arco` | 4:5 | Hero (moldura em arco) |
| `hero-detalhe` | 1:1 | Hero (círculo sobreposto) |
| `atelie-maos` | 4:5 | Manifesto |
| `curadoria-ornamentais` | 4:5 | Curadoria 01 |
| `curadoria-arranjos` | 1:1 | Curadoria 02 |
| `curadoria-variedades` | 1:1 | Curadoria 03 |
| `curadoria-flores` | 4:5 | Curadoria 04 |
| `loja-interior` | 16:9 | Visita |
| `cta-fundo` | 21:9 | Fundo do CTA final (opcional) |

Prompts e briefing de fotografia: seção 8 do documento de direção de marca.

### Avaliações
O site afirma **nota 5,0 em avaliações reais** (informação do briefing), mas **nenhum texto de cliente foi inventado**.
- Adicione cada avaliação em `reviews.ts` com `verified: true`.
- Entradas `verified: false` são modelos de layout: só aparecem em `npm run dev`, com selo "modelo". **Em produção nunca aparecem.**
- Sem nenhuma avaliação verificada, a seção mostra o selo 5,0 + um convite para conversar no WhatsApp.

## Performance (60 FPS)
- Scroll **nativo**; sem biblioteca de smooth-scroll, sem scroll-jacking.
- Header e botão flutuante usam `IntersectionObserver` (nenhum listener de `scroll` nosso).
- Animações só de `transform` e `opacity`; `LazyMotion` + `domAnimation` + `m.*`.
- Parallax em **uma** camada (hero), só em desktop com mouse; desligado em mobile e com `prefers-reduced-motion`.
- Sem `backdrop-filter`, sem `mix-blend-mode`, sem camada fixa em tela cheia.
- `next/font` (sem layout shift), `next/image` (AVIF/WebP, `priority` só no hero), seções em Server Components.

Medição local (Chromium headless, scroll contínuo de 8 s pela página inteira):
**60 fps médios · p99 = 16,8 ms · 0 quadros > 25 ms · 0 long tasks.**
Meça também no celular real do cliente antes de publicar.

## Estrutura

```
src/
  app/            layout (fontes, SEO, JSON-LD), page, globals.css, robots, sitemap, icon
  components/
    sections/     Hero · Manifesto · Curadoria · Encomendas · Avaliacoes · Cuidados · Visita · CtaFinal
    motion/       MotionProvider · Reveal · RevealLines · ParallaxFrame
    ui/           Photo · Botanical (ilustração procedural) · WhatsAppButton · Wordmark · Headings · icons
    Header · Footer · OrderPlanner · WhatsAppFloat
  content/        site.ts · reviews.ts
  lib/            whatsapp.ts · photos.ts · botanical.ts
docs/             DIRECAO-DE-MARCA.md
```

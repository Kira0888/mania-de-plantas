# Mania de Plantas — Direção de Marca

> Floricultura & Garden Center · Encomendas de flores · Curadoria botânica
> Documento-mãe do projeto. O código em `src/` implementa exatamente o que está aqui.

---

## 0. Ponto de partida honesto

| O que sabemos (do briefing) | O que **não** inventamos |
|---|---|
| Nome, nicho, o que vende, público | Endereço, bairro, horário de funcionamento |
| WhatsApp oficial **(61) 99984-2506** | Instagram, Google Maps, redes |
| Nota **5,0** baseada em avaliações reais | Número de avaliações, nomes e textos de clientes |
| Sem identidade visual prévia | Anos de mercado, fornecedores, prêmios, preços |

Tudo que falta vive em **um único arquivo** (`src/content/site.ts`) e, quando está vazio, a interface simplesmente não mostra o bloco — nunca preenche com dado falso.

---

## 1. BRAND STRATEGY

### 1.1 Ideia central
**"Mania" é cuidado repetido com amor.**
No português do dia a dia, "ter mania de" algo é uma devoção pequena e teimosa — a mania de regar às sete, de escolher a folha mais firme, de caprichar no laço. A marca pega essa palavra, normalmente meio pejorativa, e a transforma em virtude: *a mania boa de cuidar do que é vivo.*

### 1.2 Posicionamento
> Para quem quer levar verde para a vida (ou para a vida de alguém) com **segurança de escolha**, a Mania de Plantas é a **boutique botânica** onde cada planta e cada flor vêm com a indicação certa — porque quem atende entende de planta e de gente.

**Contra quem nos posicionamos:** o garden center-depósito (vasos empilhados, atendimento por etiqueta) e a floricultura-catálogo (buquê padrão, sem conversa). Somos o **meio-termo raro**: acervo de garden center, alma de ateliê.

### 1.3 Plataforma de marca

| Camada | Definição |
|---|---|
| **Essência** | Cuidar é uma arte pequena e diária |
| **Promessa** | Você sai com a planta certa para a sua luz, a sua casa e a sua rotina — ou com a flor certa para o momento de quem vai receber |
| **Arquétipo** | *Cuidador* (70%) + *Artesão* (30%) — acolhe primeiro, faz com as mãos depois |
| **Pilares** | **Curadoria** · **Acolhimento** · **Ofício** |
| **Prova** | Nota 5,0 sustentada por avaliações reais — nossa única "prova social" e a mais forte possível |
| **Assinatura** | *A mania boa de cuidar.* |

### 1.4 Público e insight
- **Presenteador sofisticado** — quer acertar, tem medo de dar "buquê genérico". *Insight: "Não sei o que combina, preciso de alguém que me guie."*
- **Amante de jardinagem / colecionador** — gosta de variedades, de conversar sobre espécie. *Insight: "Quero um lugar onde falem a minha língua."*
- **Morador da região** — valoriza loja de bairro com gente de verdade. *Insight: "Prefiro pagar por atendimento que me ensina a não matar a planta."*

### 1.5 Tom de voz
**Somos:** calorosos, precisos, calmos, um pouco poéticos. Falamos como uma pessoa que conhece folha pelo nome e cliente pelo rosto.
**Não somos:** vendedores gritando promoção, "fofos" de internet, técnicos de manual.

| Faça | Evite |
|---|---|
| "Conte a ocasião, a gente sugere o resto." | "COMPRE JÁ! Aproveite!" |
| "Antes de regar, toque na terra." | "Dicas incríveis para plantas!" |
| Frases curtas, verbo no presente | Jargão botânico sem tradução |
| Itálico em **uma** palavra por título | Exclamação em série, emoji em título |

---

## 2. CREATIVE DIRECTION

### 2.1 Conceito: **Estufa Editorial**
O site é uma revista de botânica que mora dentro de uma estufa. Duas referências fundidas:

1. **O arco do conservatório** — a janela arqueada de estufa vira a *forma-assinatura* da marca (molduras de foto, selo, ícone).
2. **A página de herbário** — papel linho, ilustração botânica em linha fina, numeração de folio (`Nº 01`), legendas pequenas em caixa-alta.

### 2.2 Princípios criativos
1. **Silêncio generoso.** Espaço negativo é luxo. Uma ideia por tela.
2. **Fotografia manda, ilustração acompanha.** A foto real é a protagonista; a ilustração botânica linear é o *cenário* e o fallback elegante.
3. **Linhas, não caixas.** Hairlines de 1px organizam; cards com sombra e cantos gordos estão proibidos.
4. **Movimento = respiração.** Só entra, devagar, uma vez. Nada pisca, nada trava, nada sequestra o scroll.
5. **Conversão discreta, constante.** O WhatsApp aparece em toda dobra relevante, sempre com o mesmo rótulo e a mesma forma.

### 2.3 Proibido (restrições do briefing + as nossas)
Gradientes roxo/azul · glassmorphism · sombras difusas grandes · cantos `rounded-2xl` em tudo · ícones de emoji · cards de feature idênticos em 3 colunas · stock photo de "pessoa sorrindo com laptop" · carrossel automático · parallax em mobile.

---

## 3. VISUAL DNA

| Elemento | Regra |
|---|---|
| **Forma-assinatura** | Arco (topo semicircular, base reta). Variações: arco grande (hero), arco pequeno (selo), oval (detalhe), retângulo de 2px de raio (editorial) |
| **Linha** | Hairline 1px em `mata` a 18% de opacidade; traço de ilustração 1.25px, terminação arredondada |
| **Ilustração** | Botânica linear gerada proceduralmente (oliveira, eucalipto, samambaia, roseta floral) — consistente, leve, sem peso de arquivo |
| **Numeração** | `Nº 01 — Curadoria` em caixa-alta espaçada; números grandes em serifada para o selo 5,0 |
| **Textura** | Papel linho sutil (ruído estático de 1 tile, sem blend-mode, sem camada fixa) |
| **Grid** | 12 colunas, margens generosas, composição **assimétrica** (foto desalinhada do texto de propósito) |
| **Ritmo de cor** | Linho → Areia → **Mata (seção escura)** → Linho → Mata (CTA final) |
| **Mood em 3 palavras** | *Úmido · Quieto · Tátil* |

---

## 4. COLOR PALETTE

Nome de cada cor vem do universo botânico. Todos os pares de texto abaixo foram medidos (WCAG 2.1).

| Token | Hex | Papel | Contraste |
|---|---|---|---|
| `mata` | `#16291D` | Texto principal, seções escuras | 13,6:1 sobre linho |
| `floresta` | `#2A4A36` | Verde de marca, botão primário | 8,7:1 sobre linho |
| `musgo` | `#4F6B4E` | Verde médio, itálicos de destaque | 5,3:1 sobre linho |
| `salvia` | `#B7C4AE` | Detalhes, linhas e ilustração em fundo escuro | 8,4:1 sobre mata |
| `neblina` | `#DCE4D4` | Tinta verde pálida (chips, fundos de foto) | — |
| `linho` | `#F5F1E8` | **Off-white base** (papel) | — |
| `papel` | `#FBF9F4` | Superfícies elevadas (inputs) | — |
| `areia` | `#E9E2D2` | Seção alternada | 11,9:1 com mata |
| `peonia` | `#9C5044` | **Único acento quente** — flor, detalhes pontuais | 5,1:1 sobre linho |
| `petala` | `#EBD3C8` | Acento sobre fundo escuro | 10,7:1 sobre mata |
| `tinta` | `#4B5E50` | Texto secundário | 6,2:1 sobre linho |

**Regra 60/30/10:** 60% linho/areia · 30% verdes · 10% peônia/pétala.
**CTA:** botão `floresta` com texto `linho` em fundo claro; botão `linho` com texto `mata` em fundo escuro. Nunca verde-WhatsApp: o CTA é *da marca*, o ícone é que sinaliza o canal.
**Peônia nunca sobre `mata`** (2,7:1 — reprova). Sobre escuro usa-se `petala`.

---

## 5. TYPOGRAPHY

| Função | Fonte | Uso |
|---|---|---|
| **Display / Editorial** | **Fraunces** (variável: `opsz`, `SOFT`) — peso 300–400, itálico para o destaque | Títulos, citações, números grandes. O eixo `SOFT` arredonda as terminações: calor "artesanal" sem perder elegância |
| **Interface / Texto** | **Hanken Grotesk** (variável) | Corpo, navegação, botões, legendas |

**Escala fluida (`clamp`)**
- Display XL (hero): `clamp(2.9rem, 1.6rem + 6vw, 7rem)` · line-height 0.98 · tracking −0.025em
- Display L (seções): `clamp(2.2rem, 1.4rem + 3.6vw, 4.5rem)` · lh 1.04
- Lead: `clamp(1.05rem, 1rem + 0.35vw, 1.25rem)` · lh 1.6
- Eyebrow/label: 0.72rem · caixa-alta · tracking 0.16em · peso 500

**Regra do itálico:** no máximo **uma palavra ou expressão curta** por título em *Fraunces itálico*, em `musgo` (fundo claro) ou `petala` (fundo escuro). É a "assinatura" tipográfica.

---

## 6. PHOTOGRAPHY DIRECTION

**Princípio:** fotografia real, de dentro da loja, com as pessoas e as plantas reais. Nada de banco de imagens.

| | |
|---|---|
| **Luz** | Natural, lateral, janela ou meia-sombra de estufa. Sombras suaves. Nunca flash direto |
| **Grade de cor** | Verdes profundos e levemente frios nas sombras; brancos quentes (linho), sem saturar. Pele natural |
| **Lente / câmera** | 50mm e 85mm (retrato e detalhe), 35mm (ambiente). Abertura f/2–f/4 |
| **Composição** | Muito respiro; sujeito fora do centro; **uma mão humana em quadro** em ~1 de cada 3 fotos (calor, escala, ofício) |
| **Superfícies** | Bancada de madeira clara, terracota crua, linho, papel kraft, cerâmica fosca |
| **Evitar** | Fundo branco de e-commerce, filtros HDR, saturação "instagram", plantas murchas, etiqueta de preço em quadro |

**Proporções que o site espera** (as molduras são recortadas via CSS, então o arquivo só precisa estar na proporção certa):
Hero `4:5` (+ detalhe `1:1`) · Curadoria `4:5` e `1:1` · Ateliê `4:5` · Loja `16:9` · Fundo do CTA `21:9`.

---

## 7. WEBSITE ARCHITECTURE

Página única (landing de marca) com âncoras — a jornada é curta e o objetivo é um só: **chegar ao WhatsApp**.

```
Header (sticky, sem blur)
 └─ Wordmark · Curadoria · Encomendas · Cuidados · Avaliações · [Encomendar]

01  HERO ───────────── "A mania boa de cuidar do que é vivo."
     Objetivo: posicionar + CTA primário + selo 5,0 imediato
02  MANIFESTO ──────── Frase editorial grande (atendimento = diferencial)
     Objetivo: explicar POR QUE somos diferentes antes de mostrar produto
03  CURADORIA ──────── 4 coleções (assimétrico, numerado)
     Plantas Ornamentais · Arranjos Vivos · Variedades Botânicas · Encomendas de Flores
     Objetivo: mostrar acervo; cada card abre o WhatsApp com mensagem específica
04  ENCOMENDAS ─────── (seção escura) 3 passos + "Monte sua mensagem"
     Objetivo: converter — chips de ocasião → mensagem pronta no WhatsApp
05  AVALIAÇÕES ─────── Selo 5,0 gigante + depoimentos reais (quando houver)
     Objetivo: confiança
06  CADERNO DE CUIDADOS  Luz · Rega · Vaso (3 respostas curtas)
     Objetivo: provar expertise e abrir conversa
07  VISITA/CONTATO ─── WhatsApp, e (quando preenchidos) endereço e horário
08  CTA FINAL ──────── (escuro) "Qual é a ocasião?" + botão
Footer

Flutuante (mobile): pílula "Encomendar no WhatsApp" — aparece depois do hero
```

**Caminhos de conversão (todos terminam em `wa.me`):**
1. Botão do hero · 2. Botão do header · 3. Link em cada coleção (mensagem contextual) · 4. Formulário guiado (ocasião + data + ideia) · 5. CTA final · 6. Pílula flutuante mobile.

**Fluxo de mensagem:** nenhum dado é enviado para servidor nosso. O texto é montado no navegador e aberto direto no WhatsApp. Zero backend, zero LGPD a gerir.

---

## 8. IMAGE GENERATION PROMPTS

Dois usos: (a) **briefing para o fotógrafo** (coluna "Foto real"), (b) **geração por IA** como provisório ou apoio de mood. O site detecta automaticamente os arquivos em `public/images/` — basta salvar com o nome indicado e rebuildar; **nenhuma linha de código muda**.

> Sufixo de estilo usado em todos os prompts (cole no final):
> `editorial botanical boutique photography, natural window light, soft shadows, deep organic green and warm off-white palette, shallow depth of field, fine film grain, muted natural colors, no text, no watermark, no logo, no price tags`

| Arquivo | Proporção | Prompt (EN) | Foto real |
|---|---|---|---|
| `hero-arco.jpg` | 4:5 | *A lush monstera deliciosa and trailing pothos in a handmade matte terracotta pot on a pale linen-draped wooden table, beside a tall arched greenhouse window with soft morning light, one woman's hands gently adjusting a leaf, vertical composition with generous negative space* | Interior da loja, janela, mãos de quem atende |
| `hero-detalhe.jpg` | 1:1 | *Macro close-up of a deep green leaf with fine water droplets and visible veins, raking side light, extremely shallow depth of field* | Detalhe de folha recém-regada |
| `curadoria-ornamentais.jpg` | 4:5 | *A curated shelf of ornamental houseplants — ficus, calathea, snake plant — in matte ceramic pots on a pale wooden shelving unit, calm and uncluttered, soft side light* | Prateleira real do acervo |
| `curadoria-arranjos.jpg` | 1:1 | *A living arrangement: small succulents, a fern and moss composed in a low stoneware bowl, kraft paper and natural twine beside it, top-down three-quarter view* | Arranjo vivo real |
| `curadoria-variedades.jpg` | 1:1 | *Rare botanical varieties in small nursery pots arranged on a zinc table in a bright greenhouse, hand-written paper plant labels, dewy leaves, cool soft light* | Bancada de variedades |
| `curadoria-flores.jpg` | 4:5 | *A hand-tied seasonal bouquet of garden roses, ranunculus and eucalyptus in dusty rose, cream and sage, wrapped in kraft paper, held by two hands over a linen apron, soft window light* | Buquê real feito na bancada |
| `atelie-maos.jpg` | 4:5 | *Close view of a florist's hands tying a bouquet with natural twine on a worn wooden workbench, flower stems and clippings around, warm tactile atmosphere, shallow depth of field* | Processo de montagem |
| `loja-interior.jpg` | 16:9 | *Wide interior of a cozy independent plant boutique, greenery layered at different heights, arched window, wooden counter, warm off-white walls, welcoming and quiet, no customers' faces* | Panorâmica da loja |
| `cta-fundo.jpg` | 21:9 | *Dark moody close-up of deep green foliage in soft shadow, layered leaves, subtle rim light, very low key, large calm negative space on the left* | Folhagem em sombra |

**Negativos (para geradores que aceitam):** `stock photo, plastic, oversaturated, HDR, neon, purple, blue tint, harsh flash, cluttered, text, watermark, logo, price tag, distorted hands, extra fingers`.

---

## 9. ENGENHARIA DE PERFORMANCE (60 FPS)

Decisões tomadas no código para que o scroll nunca engasgue:

| Decisão | Por quê |
|---|---|
| **Scroll nativo.** Sem Lenis/smooth-scroll JS, sem scroll-jacking | Bibliotecas de smooth scroll reescrevem o scroll na main thread e geram lag em aparelho modesto |
| **Nenhum listener de `scroll` nosso** — header e botão flutuante usam `IntersectionObserver` | Observer roda fora do caminho crítico de input |
| **Só `transform` e `opacity`** em toda animação | Ficam na GPU (compositor) — nenhum layout ou paint por quadro |
| **`LazyMotion` + `domAnimation` + componente `m`** | ~15 KB em vez de ~35 KB de JS de animação |
| **`whileInView` com `once: true`** | Cada elemento anima uma única vez e é desligado |
| **Parallax só no hero, só em desktop com mouse, só 1 camada** (`useScroll` → `useTransform`); em mobile e com movimento reduzido a camada fica parada | MotionValues atualizam o DOM direto, sem re-render React |
| **Sem `backdrop-filter`, sem `mix-blend-mode`, sem camada fixa full-screen** | São os maiores vilões de repaint em scroll |
| **Selo rotativo = CSS `transform`** (compositor), desligado em `prefers-reduced-motion` | Contínuo, mas custo ≈ 0 |
| **`next/font`** com `display: swap` e subset latin | Sem layout shift, sem requisição bloqueante |
| **`next/image`** com `sizes`, AVIF/WebP, `priority` só no hero | LCP rápido, bytes mínimos |
| **Seções são Server Components**; só os "ilhéus" interativos são client | Menos JS hidratado |
| **`MotionConfig reducedMotion="user"`** | Acessibilidade: movimento reduzido respeitado em todo o site |
| **`content-visibility: auto` descartado de propósito** | Em páginas curtas o ganho é pequeno e as estimativas de altura causam saltos na barra de rolagem — o oposto do objetivo |

---

## 10. PENDÊNCIAS PARA O CLIENTE (preencher em `src/content/site.ts`)

- [ ] Fotos reais (ver tabela da seção 8) → `public/images/`
- [ ] Avaliações reais (texto, primeiro nome, origem) → `src/content/reviews.ts` com `verified: true`
- [ ] Link das avaliações no Google (botão "Ver todas")
- [ ] Endereço, horário e link do mapa
- [ ] Instagram
- [ ] Confirmar se há **entrega** (o passo 3 de "Encomendas" fala em "entrega ou retirada")
- [ ] Domínio final (`siteUrl`) para canonical, sitemap e dados estruturados

---

## 11. RESULTADO MEDIDO

Build de produção, Chromium headless (CPU), scroll contínuo de 8 s pela página inteira (≈10 700 px):

| Métrica | Resultado |
|---|---|
| FPS médio | **60** |
| p95 / p99 / pior quadro | 16,7 / 16,8 / 16,8 ms |
| Quadros acima de 25 ms | **0** |
| Long tasks (>50 ms) | **0** |
| Overflow horizontal (390 px e 1440 px) | nenhum |
| Erros de console | nenhum |
| Páginas geradas | 100% estáticas |

Verificado também: planner → mensagem pré-preenchida no WhatsApp oficial (13 CTAs apontam para o mesmo número), menu mobile (abre, trava scroll, fecha com Esc), pílula flutuante (aparece após o hero, some no CTA final), alvos de toque ≥ 44 px, fontes carregadas.
**Pendente:** medir em aparelho real de entrada (Android modesto) e rodar Lighthouse no domínio publicado.

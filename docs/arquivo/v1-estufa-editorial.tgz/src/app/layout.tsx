import type { Metadata, Viewport } from "next";
import { Fraunces, Hanken_Grotesk } from "next/font/google";
import { MotionProvider } from "@/components/motion/MotionProvider";
import { site } from "@/content/site";
import "./globals.css";

/**
 * Fraunces — serifada de display. Eixos opsz (tamanho óptico) e SOFT (terminações suaves)
 * dão o calor "artesanal" sem perder a elegância editorial.
 */
const fraunces = Fraunces({
  subsets: ["latin"],
  style: ["normal", "italic"],
  axes: ["opsz", "SOFT"],
  variable: "--font-fraunces",
  display: "swap",
});

const hanken = Hanken_Grotesk({
  subsets: ["latin"],
  variable: "--font-hanken",
  display: "swap",
});

const title = `${site.name} — ${site.descriptor} | Plantas, arranjos vivos e encomendas de flores`;

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: title, template: `%s | ${site.name}` },
  description: site.description,
  applicationName: site.name,
  alternates: { canonical: "/" },
  keywords: [
    "floricultura",
    "garden center",
    "plantas ornamentais",
    "arranjos vivos",
    "encomenda de flores",
    "buquê de flores",
    "presente com plantas",
    "variedades botânicas",
    "Mania de Plantas",
  ],
  openGraph: {
    type: "website",
    locale: "pt_BR",
    siteName: site.name,
    title,
    description: site.description,
    url: "/",
  },
  twitter: { card: "summary_large_image", title, description: site.description },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#f5f1e8",
  width: "device-width",
  initialScale: 1,
};

/** Dados estruturados: Florist (schema.org). Só campos confirmados — sem avaliação inventada. */
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Florist",
  name: site.name,
  description: site.description,
  url: site.url,
  telephone: `+${site.whatsapp.number}`,
  slogan: site.tagline,
  ...(site.address ? { address: site.address } : {}),
  ...(site.instagram ? { sameAs: [site.instagram.url] } : {}),
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${fraunces.variable} ${hanken.variable}`}>
      <body>
        {/* Sem JS, as entradas animadas não podem deixar o conteúdo invisível */}
        <noscript>
          <style>{`[style*="opacity: 0"],[style*="opacity:0"]{opacity:1!important;transform:none!important}`}</style>
        </noscript>

        <a
          href="#conteudo"
          className="fixed top-3 left-3 z-[100] -translate-y-20 rounded-full bg-mata px-5 py-3 text-sm text-linho transition-transform focus:translate-y-0"
        >
          Pular para o conteúdo
        </a>

        <MotionProvider>{children}</MotionProvider>

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
        />
      </body>
    </html>
  );
}

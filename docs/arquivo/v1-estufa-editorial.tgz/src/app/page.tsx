import { Footer } from "@/components/Footer";
import { Header } from "@/components/Header";
import { WhatsAppFloat } from "@/components/WhatsAppFloat";
import { Avaliacoes } from "@/components/sections/Avaliacoes";
import { CtaFinal } from "@/components/sections/CtaFinal";
import { Cuidados } from "@/components/sections/Cuidados";
import { Curadoria } from "@/components/sections/Curadoria";
import { Encomendas } from "@/components/sections/Encomendas";
import { Hero } from "@/components/sections/Hero";
import { Manifesto } from "@/components/sections/Manifesto";
import { Visita } from "@/components/sections/Visita";

export default function Home() {
  return (
    <>
      <Header />
      <main id="conteudo">
        <Hero />
        <Manifesto />
        <Curadoria />
        <Encomendas />
        <Avaliacoes />
        <Cuidados />
        <Visita />
        <CtaFinal />
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  );
}

/**
 * FONTE ÚNICA DE VERDADE do site.
 * Tudo que é copy, contato e dado do negócio vive aqui.
 *
 * Regra: campo `null` = informação ainda não confirmada → a interface
 * esconde o bloco. Nunca preencher com dado inventado.
 */

export const site = {
  name: "Mania de Plantas",
  descriptor: "Floricultura & Garden Center",
  tagline: "A mania boa de cuidar.",
  description:
    "Plantas ornamentais escolhidas a dedo, arranjos vivos, variedades botânicas e encomendas de flores sob medida. Atendimento especializado e nota 5,0 em avaliações reais de clientes. Peça pelo WhatsApp.",

  /** Domínio final. Defina NEXT_PUBLIC_SITE_URL em produção. */
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",

  whatsapp: {
    /** Formato internacional, só dígitos: 55 + DDD + número */
    number: "5561999842506",
    display: "(61) 99984-2506",
    cta: "Fazer Encomenda no WhatsApp",
    ctaShort: "Encomendar",
    defaultMessage: "Olá, Mania de Plantas! Gostaria de fazer uma encomenda.",
  },

  rating: {
    score: "5,0",
    caption: "Nota máxima em avaliações reais de clientes",
  },

  // ── A PREENCHER PELO CLIENTE (null = bloco não aparece) ──────────────
  googleReviewsUrl: null as string | null,
  instagram: null as { handle: string; url: string } | null,
  address: null as string | null,
  mapsUrl: null as string | null,
  hours: null as string[] | null,
  /** Mude para true SOMENTE se a loja realmente faz entrega. */
  delivers: true,
} as const;

export type Site = typeof site;

export const nav = [
  { label: "Curadoria", href: "#curadoria" },
  { label: "Encomendas", href: "#encomendas" },
  { label: "Cuidados", href: "#cuidados" },
  { label: "Avaliações", href: "#avaliacoes" },
  { label: "Visita", href: "#visita" },
] as const;

/* ── HERO ─────────────────────────────────────────────────────────────── */
export const hero = {
  eyebrow: "Floricultura & Garden Center",
  // Cada item é uma linha do título (máscara de entrada). `em` = destaque em itálico.
  titleLines: [
    [{ t: "A mania boa de" }],
    [{ t: "cuidar", em: true }, { t: " do que" }],
    [{ t: "é vivo." }],
  ],
  lead: "Plantas ornamentais escolhidas a dedo, arranjos vivos e encomendas de flores feitas sob medida — com o atendimento de quem entende de planta e de gente.",
  secondaryCta: { label: "Conhecer a curadoria", href: "#curadoria" },
  caption: "Atendimento que ensina a cuidar.",
} as const;

/* ── MANIFESTO ────────────────────────────────────────────────────────── */
export const manifesto = {
  eyebrow: "Nº 01 — O jeito Mania",
  text: [
    { t: "Toda casa merece um pedaço de " },
    { t: "verde", em: true },
    { t: " que combine com ela. Aqui você não leva só uma planta: leva a indicação certa de luz, de rega e de vaso — e um jeito de cuidar que " },
    { t: "dá certo", em: true },
    { t: "." },
  ],
  pillars: [
    { title: "Curadoria", body: "Cada planta é escolhida pela saúde da folha e pelo caráter da espécie." },
    { title: "Acolhimento", body: "Conversa sem pressa, sem jargão e sem pergunta boba." },
    { title: "Ofício", body: "Arranjos e buquês montados à mão, um por um." },
  ],
} as const;

/* ── CURADORIA ────────────────────────────────────────────────────────── */
export const curadoria = {
  eyebrow: "Nº 02 — Curadoria",
  title: { before: "Quatro jeitos de levar o ", em: "verde", after: " para perto." },
  lead: "Do vaso que acompanha o dia a dia ao buquê que diz o que as palavras não alcançam.",
  items: [
    {
      id: "ornamentais",
      n: "01",
      title: "Plantas Ornamentais",
      body: "Folhagens e plantas para dentro e para fora de casa, escolhidas pela saúde da folha e pelo caráter de cada espécie.",
      photo: "curadoria-ornamentais",
      alt: "Prateleira de plantas ornamentais em vasos de cerâmica fosca",
      plate: "olive",
      tone: "light",
      message: "Olá, Mania de Plantas! Quero ajuda para escolher uma planta ornamental.",
    },
    {
      id: "arranjos",
      n: "02",
      title: "Arranjos Vivos",
      body: "Composições com plantas vivas, vasos e cachepôs escolhidos a dedo. Um presente que continua crescendo.",
      photo: "curadoria-arranjos",
      alt: "Arranjo vivo de suculentas, samambaia e musgo em uma tigela de grês",
      plate: "fern",
      tone: "sand",
      message: "Olá, Mania de Plantas! Quero encomendar um arranjo vivo.",
    },
    {
      id: "variedades",
      n: "03",
      title: "Variedades Botânicas",
      body: "Espécies para quem coleciona, experimenta e gosta de descobrir. Pergunte o que chegou de novo.",
      photo: "curadoria-variedades",
      alt: "Variedades botânicas em vasos de viveiro sobre uma bancada",
      plate: "eucalyptus",
      tone: "light",
      message: "Olá, Mania de Plantas! Quais variedades botânicas vocês têm disponíveis?",
    },
    {
      id: "flores",
      n: "04",
      title: "Encomendas de Flores",
      body: "Buquês e arranjos de flores feitos sob medida para a ocasião, a paleta e o orçamento que você tiver.",
      photo: "curadoria-flores",
      alt: "Buquê de flores em tons de rosa seco e creme embrulhado em papel kraft",
      plate: "flowers",
      tone: "rose",
      message: "Olá, Mania de Plantas! Quero encomendar flores.",
    },
  ],
} as const;

/* ── ENCOMENDAS ───────────────────────────────────────────────────────── */
export const encomendas = {
  eyebrow: "Nº 03 — Encomendas",
  title: { before: "Encomendas feitas ", em: "sob medida", after: "." },
  lead: "Você conta a ocasião. A gente desenha o resto com você — e tudo acontece numa conversa de WhatsApp.",
  steps: [
    { n: "1", title: "Conte a ocasião", body: "Aniversário, casa nova, agradecimento, saudade. Diga para quem é e o que quer transmitir." },
    { n: "2", title: "Desenhamos com você", body: "Sugerimos flores, plantas e vaso conforme o estilo e o orçamento. Você ajusta até ficar do seu jeito." },
    { n: "3", title: "Combine e receba", body: "Alinhamos a data e a forma de entrega ou retirada." },
  ],
  planner: {
    title: "Comece sua encomenda",
    hint: "Escolha a ocasião — a mensagem já segue pronta para o nosso WhatsApp.",
    occasions: ["Presente", "Aniversário", "Casa nova", "Homenagem", "Decoração", "Outra ocasião"],
    whenLabel: "Para quando?",
    whenPlaceholder: "Ex.: sábado de manhã",
    ideaLabel: "Ideia ou preferência?",
    ideaPlaceholder: "Ex.: tons suaves, algo que dure bastante",
    submit: "Enviar pelo WhatsApp",
    privacy: "Nada é guardado em nosso site. A mensagem abre direto no seu WhatsApp.",
  },
} as const;

/* ── AVALIAÇÕES ───────────────────────────────────────────────────────── */
export const avaliacoes = {
  eyebrow: "Nº 04 — Avaliações",
  title: { before: "Nota máxima, construída ", em: "um atendimento", after: " por vez." },
  caption: "Nota 5,0 em avaliações reais de clientes.",
  emptyText:
    "Quem já passou por aqui conta melhor do que a gente. Venha formar a sua própria opinião: o atendimento é o nosso melhor argumento.",
  seeAll: "Ver avaliações no Google",
} as const;

/* ── CADERNO DE CUIDADOS ──────────────────────────────────────────────── */
export const cuidados = {
  eyebrow: "Nº 05 — Caderno de cuidados",
  title: { before: "Três perguntas antes de ", em: "levar", after: " uma planta." },
  lead: "A gente faz essas perguntas em toda conversa. Responder já resolve metade do caminho.",
  items: [
    {
      icon: "sun",
      title: "Luz",
      question: "Onde ela vai ficar?",
      body: "Observe onde bate sol e por quantas horas. Isso decide quase tudo — a gente indica a espécie certa para o seu canto.",
    },
    {
      icon: "drop",
      title: "Rega",
      question: "Quando molhar?",
      body: "Antes de regar, toque na terra. Planta de casa costuma sofrer mais por excesso de água do que por falta.",
    },
    {
      icon: "pot",
      title: "Vaso",
      question: "Onde ela vai morar?",
      body: "Vaso com furo de drenagem e um pouco maior que a raiz. Cachepô é enfeite; o vaso é quem cuida da planta.",
    },
  ],
  cta: { label: "Tire sua dúvida no WhatsApp", message: "Olá, Mania de Plantas! Tenho uma dúvida sobre cuidados com minha planta." },
} as const;

/* ── VISITA ───────────────────────────────────────────────────────────── */
export const visita = {
  eyebrow: "Nº 06 — Visita",
  title: { before: "Venha ", em: "conversar", after: " com a gente." },
  lead: "A melhor planta é a que a gente escolhe junto, olhando a folha de perto. Chame no WhatsApp e combine sua visita.",
  photo: { name: "loja-interior", alt: "Interior da loja Mania de Plantas, com plantas em diferentes alturas e uma janela em arco" },
} as const;

/* ── CTA FINAL ────────────────────────────────────────────────────────── */
export const ctaFinal = {
  titleLines: [
    [{ t: "Qual é a" }],
    [{ t: "ocasião", em: true }, { t: "?" }],
  ],
  lead: "Conte para a gente. Do vaso para a mesa de trabalho ao buquê para quem você ama, a gente cuida do verde.",
  message: "Olá, Mania de Plantas! Gostaria de fazer uma encomenda.",
} as const;

export const footer = {
  note: "Plantas e flores com a mania boa de cuidar.",
} as const;

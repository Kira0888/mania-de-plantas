/**
 * AVALIAÇÕES
 *
 * ⚠️  Este arquivo NÃO contém avaliações reais ainda.
 * O site se apresenta com nota 5,0 baseada em avaliações reais de clientes
 * (informação do briefing), mas o TEXTO de cada depoimento precisa vir do
 * Google/Instagram/WhatsApp do cliente — nunca inventado.
 *
 * Como usar:
 *   1. Copie a avaliação exatamente como foi escrita (pode encurtar com "…").
 *   2. Adicione abaixo com `verified: true`.
 *   3. Pronto — aparece no site.
 *
 * Entradas com `verified: false` são MODELOS de layout: só aparecem em
 * `npm run dev` (com selo "modelo"), e NUNCA em produção.
 */

export type Review = {
  /** Texto exato da avaliação */
  quote: string;
  /** Primeiro nome (ou nome + inicial) como aparece na avaliação */
  author: string;
  /** Onde foi publicada: "Google", "Instagram", "WhatsApp"… */
  source: string;
  /** true = avaliação real, confirmada pelo cliente da loja */
  verified: boolean;
};

export const reviews: Review[] = [
  // ── modelos de layout (não aparecem em produção) ──────────────────────
  {
    quote: "Aqui entra o texto real de uma avaliação de cliente.",
    author: "Nome do cliente",
    source: "Google",
    verified: false,
  },
  {
    quote: "Segunda avaliação real — de preferência uma que cite o atendimento.",
    author: "Nome do cliente",
    source: "Google",
    verified: false,
  },
  {
    quote: "Terceira avaliação real — pode ser sobre uma encomenda de flores.",
    author: "Nome do cliente",
    source: "Instagram",
    verified: false,
  },
];

/** O que de fato renderiza: reais sempre; modelos só em desenvolvimento. */
export function visibleReviews(): Review[] {
  const isDev = process.env.NODE_ENV !== "production";
  return reviews.filter((r) => r.verified || isDev);
}

/**
 * Gerador procedural de ilustração botânica linear.
 *
 * Por que código e não imagens? Peso zero, nitidez infinita, 100% consistente
 * com a marca, e serve de "placa de herbário" elegante enquanto as fotos reais
 * não chegam. Tudo é determinístico (seed fixo): server e client geram o mesmo.
 */

type Pt = { x: number; y: number };

const r2 = (n: number) => Math.round(n * 100) / 100;
const rad = (deg: number) => (deg * Math.PI) / 180;

/** PRNG pequeno e determinístico (mulberry32). */
function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function quad(p0: Pt, c: Pt, p1: Pt, t: number): Pt {
  const u = 1 - t;
  return {
    x: u * u * p0.x + 2 * u * t * c.x + t * t * p1.x,
    y: u * u * p0.y + 2 * u * t * c.y + t * t * p1.y,
  };
}

/** Ângulo (graus) da tangente da curva em t. */
function tangent(p0: Pt, c: Pt, p1: Pt, t: number): number {
  const dx = 2 * (1 - t) * (c.x - p0.x) + 2 * t * (p1.x - c.x);
  const dy = 2 * (1 - t) * (c.y - p0.y) + 2 * t * (p1.y - c.y);
  return (Math.atan2(dy, dx) * 180) / Math.PI;
}

/** Aplica rotação + translação a um ponto local da folha. */
function place(o: Pt, angleDeg: number, x: number, y: number): Pt {
  const a = rad(angleDeg);
  return { x: o.x + x * Math.cos(a) - y * Math.sin(a), y: o.y + x * Math.sin(a) + y * Math.cos(a) };
}

/** Folha em formato de lança/gota, apontando para +x no espaço local. */
function leaf(o: Pt, angle: number, len: number, wid: number, fat = 0.7) {
  const P = (x: number, y: number) => {
    const p = place(o, angle, x, y);
    return `${r2(p.x)} ${r2(p.y)}`;
  };
  const body =
    `M${P(0, 0)}` +
    `C${P(len * 0.22, -wid)} ${P(len * fat, -wid)} ${P(len, 0)}` +
    `C${P(len * fat, wid)} ${P(len * 0.22, wid)} ${P(0, 0)}Z`;
  const rib = `M${P(0, 0)}L${P(len * 0.88, 0)}`;
  return { body, rib };
}

export type BranchKind = "olive" | "eucalyptus" | "fern";

export type BranchSpec = {
  kind: BranchKind;
  p0: Pt;
  c: Pt;
  p1: Pt;
  count: number;
  size?: number;
  seed?: number;
};

export type Art = { stem: string; leaves: string; ribs: string };

export function branch(spec: BranchSpec): Art {
  const { kind, p0, c, p1, count, size = 1, seed = 7 } = spec;
  const rand = rng(seed);
  const stem = `M${r2(p0.x)} ${r2(p0.y)}Q${r2(c.x)} ${r2(c.y)} ${r2(p1.x)} ${r2(p1.y)}`;
  let leaves = "";
  let ribs = "";

  const add = (o: Pt, angle: number, len: number, wid: number, fat?: number) => {
    const l = leaf(o, angle, len, wid, fat);
    leaves += l.body;
    ribs += l.rib;
  };

  for (let i = 0; i < count; i++) {
    const t = 0.1 + 0.86 * (i / Math.max(1, count - 1));
    const o = quad(p0, c, p1, t);
    const base = tangent(p0, c, p1, t);
    const jitter = (rand() - 0.5) * 8;

    if (kind === "olive") {
      const s = 1 - 0.45 * t;
      const side = i % 2 === 0 ? -1 : 1;
      add(o, base + side * (46 + jitter), 36 * size * s, 5.6 * size * s, 0.62);
    } else if (kind === "eucalyptus") {
      const s = 1 - 0.42 * t;
      const len = 23 * size * s;
      add(o, base - (66 + jitter), len, len * 0.62, 0.78);
      add(o, base + (66 - jitter), len * 0.94, len * 0.58, 0.78);
    } else {
      // samambaia: pinas em pares, mais longas no meio, afinando para a ponta
      const prof = Math.sin(Math.PI * Math.min(1, t * 0.92 + 0.06)) * 0.75 + 0.25;
      const len = 30 * size * prof * (1 - 0.35 * t);
      add(o, base - (60 + jitter), len, 3.8 * size * prof, 0.55);
      add(o, base + (60 - jitter), len, 3.8 * size * prof, 0.55);
    }
  }

  // folha terminal na ponta do galho
  const endAngle = tangent(p0, c, p1, 1);
  if (kind === "olive") add(p1, endAngle, 26 * size, 4.6 * size, 0.62);
  if (kind === "eucalyptus") add(p1, endAngle, 17 * size, 10 * size, 0.78);
  if (kind === "fern") add(p1, endAngle, 14 * size, 3 * size, 0.55);

  return { stem, leaves, ribs };
}

/** Flor em roseta (peônia/ranúnculo estilizada) em linha. */
export function rosette(cx: number, cy: number, r: number, seed = 3): { petals: string; center: string } {
  const rand = rng(seed);
  const rings = [
    { n: 10, len: r, wid: r * 0.34, off: 0 },
    { n: 8, len: r * 0.74, wid: r * 0.3, off: 360 / 10 / 2 },
    { n: 6, len: r * 0.48, wid: r * 0.24, off: 360 / 8 / 2 },
  ];
  let petals = "";
  for (const ring of rings) {
    for (let i = 0; i < ring.n; i++) {
      const a = ring.off + (360 / ring.n) * i + (rand() - 0.5) * 6;
      petals += leaf({ x: cx, y: cy }, a, ring.len, ring.wid, 0.78).body;
    }
  }
  const cr = r * 0.1;
  const center = `M${r2(cx - cr)} ${r2(cy)}a${r2(cr)} ${r2(cr)} 0 1 0 ${r2(cr * 2)} 0a${r2(cr)} ${r2(cr)} 0 1 0 ${r2(-cr * 2)} 0Z`;
  return { petals, center };
}

/** Arco de estufa (contorno). */
export const ARCH_PATH = "M70 500V225A130 130 0 0 1 330 225V500";

import "server-only";
import fs from "node:fs";
import path from "node:path";

const EXTENSIONS = [".avif", ".webp", ".jpg", ".jpeg", ".png"] as const;

/**
 * Procura `public/images/<nome>.(avif|webp|jpg|jpeg|png)`.
 * Roda no servidor, em tempo de build/render. Se existir, devolve a URL pública;
 * se não, devolve null e o site mostra a placa botânica ilustrada.
 *
 * → Para trocar uma foto: salve o arquivo com o nome certo e rebuilde. Só isso.
 */
export function resolvePhoto(name: string): string | null {
  const dir = path.join(process.cwd(), "public", "images");
  for (const ext of EXTENSIONS) {
    if (fs.existsSync(path.join(dir, `${name}${ext}`))) return `/images/${name}${ext}`;
  }
  return null;
}

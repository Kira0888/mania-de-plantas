"use client";

import { useId, useMemo, useState, type FormEvent } from "react";
import { encomendas } from "@/content/site";
import { waLink } from "@/lib/whatsapp";
import { ArrowIcon, WhatsAppIcon } from "./ui/icons";

/**
 * "Comece sua encomenda": ocasião + data + ideia → mensagem pronta no WhatsApp.
 * Nada é enviado para servidor nosso: o texto é montado aqui e aberto direto no WhatsApp.
 */
export function OrderPlanner() {
  const p = encomendas.planner;
  const uid = useId();
  const [occasion, setOccasion] = useState<string | null>(null);
  const [when, setWhen] = useState("");
  const [idea, setIdea] = useState("");

  const message = useMemo(() => {
    const lines = ["Olá, Mania de Plantas! Quero fazer uma encomenda."];
    if (occasion) lines.push("", `Ocasião: ${occasion}`);
    if (when.trim()) lines.push(`Para quando: ${when.trim()}`);
    if (idea.trim()) lines.push(`Ideias: ${idea.trim()}`);
    return lines.join("\n");
  }, [occasion, when, idea]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    window.open(waLink(message), "_blank", "noopener,noreferrer");
  }

  const field =
    "mt-2 w-full border-0 border-b border-salvia/40 bg-transparent px-0 py-3 text-[1rem] text-linho placeholder:text-salvia/55 transition-colors duration-300 focus:border-petala focus:outline-none";

  return (
    <form
      onSubmit={onSubmit}
      className="rounded-[3px] border border-salvia/25 bg-floresta/45 p-7 sm:p-10"
      aria-labelledby={`${uid}-titulo`}
    >
      <h3 id={`${uid}-titulo`} className="t-display text-display-m">
        {p.title}
      </h3>
      <p className="mt-3 max-w-md text-[0.95rem] leading-relaxed text-salvia">{p.hint}</p>

      <fieldset className="mt-8">
        <legend className="eyebrow text-salvia">Ocasião</legend>
        <div className="mt-4 flex flex-wrap gap-2.5">
          {p.occasions.map((o) => {
            const active = occasion === o;
            return (
              <button
                key={o}
                type="button"
                aria-pressed={active}
                onClick={() => setOccasion(active ? null : o)}
                className={`h-11 rounded-full border px-5 text-[0.92rem] transition-colors duration-300 ${
                  active
                    ? "border-linho bg-linho text-mata"
                    : "border-salvia/40 text-linho hover:border-linho"
                }`}
              >
                {o}
              </button>
            );
          })}
        </div>
      </fieldset>

      <div className="mt-8 grid gap-8 sm:grid-cols-2">
        <div>
          <label htmlFor={`${uid}-quando`} className="eyebrow text-salvia">
            {p.whenLabel}
          </label>
          <input
            id={`${uid}-quando`}
            type="text"
            value={when}
            onChange={(e) => setWhen(e.target.value)}
            placeholder={p.whenPlaceholder}
            className={field}
            autoComplete="off"
          />
        </div>
        <div>
          <label htmlFor={`${uid}-ideia`} className="eyebrow text-salvia">
            {p.ideaLabel}
          </label>
          <input
            id={`${uid}-ideia`}
            type="text"
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            placeholder={p.ideaPlaceholder}
            className={field}
            autoComplete="off"
          />
        </div>
      </div>

      <button
        type="submit"
        className="group mt-10 inline-flex h-14 w-full items-center justify-center gap-3 rounded-full bg-linho px-7 font-medium text-mata transition-colors duration-500 hover:bg-papel sm:w-auto"
      >
        <WhatsAppIcon className="h-5 w-5" />
        {p.submit}
        <ArrowIcon className="h-[1.1em] w-[1.1em] -translate-x-1 opacity-60 transition-[transform,opacity] duration-500 group-hover:translate-x-0 group-hover:opacity-100" />
        <span className="sr-only"> (abre o WhatsApp em nova aba)</span>
      </button>

      <p className="mt-5 text-[0.8rem] leading-relaxed text-salvia/80">{p.privacy}</p>
    </form>
  );
}

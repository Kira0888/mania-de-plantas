"use client";

import { AnimatePresence, m } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { nav, site } from "@/content/site";
import { waLink } from "@/lib/whatsapp";
import { CloseIcon, MenuIcon, WhatsAppIcon } from "./ui/icons";
import { Wordmark } from "./ui/Wordmark";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const sentinel = useRef<HTMLDivElement>(null);

  // Sem listener de scroll: um IntersectionObserver observa uma "sentinela" no topo da página.
  useEffect(() => {
    const el = sentinel.current;
    if (!el) return;
    const io = new IntersectionObserver(([entry]) => setScrolled(!entry.isIntersecting));
    io.observe(el);
    return () => io.disconnect();
  }, []);

  // Menu mobile: trava o scroll do body e fecha com Esc.
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const dark = open;

  return (
    <>
      <div ref={sentinel} aria-hidden="true" className="pointer-events-none absolute top-0 left-0 h-14 w-px" />
      <header
        className={`sticky top-0 z-50 border-b transition-[background-color,border-color,color] duration-500 ${
          dark
            ? "on-dark border-transparent bg-mata text-linho"
            : scrolled
              ? "border-mata/10 bg-linho text-mata"
              : "border-transparent bg-linho/0 text-mata"
        }`}
      >
        <div className="wrap flex h-[4.5rem] items-center justify-between gap-6">
          <a href="#inicio" aria-label={`${site.name} — início`} onClick={() => setOpen(false)} className="shrink-0">
            <Wordmark invert={dark} />
          </a>

          <nav aria-label="Principal" className="hidden items-center gap-9 lg:flex">
            {nav.map((item) => (
              <a key={item.href} href={item.href} className="link-draw text-[0.92rem] font-medium">
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={waLink()}
              target="_blank"
              rel="noopener noreferrer"
              className={`hidden h-11 items-center gap-2.5 rounded-full px-5 text-[0.9rem] font-medium transition-colors duration-500 sm:inline-flex ${
                dark ? "bg-linho text-mata hover:bg-papel" : "bg-floresta text-linho hover:bg-mata"
              }`}
            >
              <WhatsAppIcon className="h-[1.1em] w-[1.1em]" />
              {site.whatsapp.ctaShort}
              <span className="sr-only"> pelo WhatsApp (abre em nova aba)</span>
            </a>

            <button
              type="button"
              className="inline-flex h-11 w-11 items-center justify-center rounded-full lg:hidden"
              aria-expanded={open}
              aria-controls="menu-mobile"
              aria-label={open ? "Fechar menu" : "Abrir menu"}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <CloseIcon className="h-6 w-6" /> : <MenuIcon className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <m.div
            id="menu-mobile"
            className="on-dark fixed inset-0 z-40 flex flex-col bg-mata px-6 pt-28 pb-10 text-linho lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
          >
            <nav aria-label="Menu" className="flex flex-col">
              {nav.map((item, i) => (
                <m.a
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="t-display border-b border-linho/15 py-5 text-4xl"
                  initial={{ opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.08 + i * 0.06, ease: [0.22, 1, 0.36, 1] }}
                >
                  {item.label}
                </m.a>
              ))}
            </nav>
            <m.a
              href={waLink()}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setOpen(false)}
              className="mt-auto inline-flex h-14 items-center justify-center gap-3 rounded-full bg-linho font-medium text-mata"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <WhatsAppIcon className="h-5 w-5" />
              {site.whatsapp.cta}
            </m.a>
          </m.div>
        )}
      </AnimatePresence>
    </>
  );
}

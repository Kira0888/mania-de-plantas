import Image from "next/image";
import { resolvePhoto } from "@/lib/photos";
import { BotanicalPlate, BotanicalPlateWide, type PlateTone, type PlateVariant } from "./Botanical";

export type Shape = "arch" | "rect" | "oval" | "pill";
export type Ratio = "4/5" | "1/1" | "16/9" | "21/9" | "3/2" | "pano";

const SHAPE: Record<Shape, string> = {
  arch: "rounded-t-full", // a forma-assinatura da marca
  rect: "rounded-[3px]",
  oval: "rounded-[50%]",
  pill: "rounded-full",
};

const RATIO: Record<Ratio, string> = {
  "4/5": "aspect-[4/5]",
  "1/1": "aspect-square",
  "16/9": "aspect-[16/9]",
  "21/9": "aspect-[21/9]",
  "3/2": "aspect-[3/2]",
  // panorâmica: 4:3 no celular (não vira uma tira fina), 16:9 a partir de md
  pano: "aspect-[4/3] md:aspect-[16/9]",
};

type FillProps = {
  /** nome do arquivo em public/images, sem extensão */
  name: string;
  alt: string;
  sizes: string;
  priority?: boolean;
  plate?: PlateVariant;
  tone?: PlateTone;
  /** moldura larga (16:9 / 21:9): usa a composição "estufa" no lugar da placa vertical */
  wide?: boolean;
};

/**
 * Preenche o contêiner pai (position: relative).
 * - Se `public/images/<name>.(avif|webp|jpg|jpeg|png)` existir → foto real (next/image).
 * - Senão → placa botânica ilustrada. Em desenvolvimento, mostra qual arquivo falta.
 */
export function PhotoFill({ name, alt, sizes, priority = false, plate = "olive", tone = "light", wide = false }: FillProps) {
  const src = resolvePhoto(name);

  if (src) {
    return <Image src={src} alt={alt} fill sizes={sizes} priority={priority} className="object-cover" />;
  }

  return (
    <>
      {wide ? <BotanicalPlateWide tone={tone} /> : <BotanicalPlate variant={plate} tone={tone} />}
      {process.env.NODE_ENV !== "production" && (
        <span className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-linho/80 px-3 py-1 font-sans text-[10px] tracking-wider whitespace-nowrap text-mata/70">
          foto: public/images/{name}.jpg
        </span>
      )}
    </>
  );
}

type FrameProps = FillProps & {
  shape?: Shape;
  ratio?: Ratio;
  className?: string;
  /** adiciona o zoom lento no hover (CSS puro) */
  zoom?: boolean;
};

/** Moldura de foto com forma e proporção da marca. */
export function Photo({ shape = "rect", ratio = "4/5", className = "", zoom = true, ...fill }: FrameProps) {
  const wide = ratio === "16/9" || ratio === "21/9" || ratio === "pano";
  return (
    <div className={`relative isolate w-full overflow-hidden bg-neblina ${SHAPE[shape]} ${RATIO[ratio]} ${zoom ? "foto-zoom" : ""} ${className}`}>
      <PhotoFill {...fill} wide={wide} />
    </div>
  );
}

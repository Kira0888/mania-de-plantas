import { ARCH_PATH, branch, rosette, type BranchSpec } from "@/lib/botanical";

export type PlateVariant = "olive" | "eucalyptus" | "fern" | "flowers" | "mixed";
export type PlateTone = "light" | "sand" | "deep" | "rose";

const TONES: Record<PlateTone, { bg: string; ink: string; soft: string }> = {
  light: { bg: "#DCE4D4", ink: "#2A4A36", soft: "#4F6B4E" },
  sand: { bg: "#E9E2D2", ink: "#2A4A36", soft: "#4F6B4E" },
  deep: { bg: "#2A4A36", ink: "#B7C4AE", soft: "#DCE4D4" },
  rose: { bg: "#EBD3C8", ink: "#9C5044", soft: "#2A4A36" },
};

const P = (x: number, y: number) => ({ x, y });

const COMPOSITIONS: Record<PlateVariant, BranchSpec[]> = {
  olive: [
    { kind: "olive", p0: P(86, 540), c: P(40, 280), p1: P(262, 56), count: 14, size: 1.5, seed: 11 },
    { kind: "olive", p0: P(372, 540), c: P(352, 380), p1: P(302, 232), count: 9, size: 1.05, seed: 5 },
  ],
  eucalyptus: [
    { kind: "eucalyptus", p0: P(322, 540), c: P(372, 290), p1: P(148, 64), count: 8, size: 1.55, seed: 9 },
    { kind: "eucalyptus", p0: P(58, 540), c: P(74, 410), p1: P(170, 300), count: 6, size: 1.1, seed: 4 },
  ],
  fern: [
    { kind: "fern", p0: P(196, 548), c: P(70, 300), p1: P(190, 36), count: 20, size: 1.7, seed: 21 },
    { kind: "fern", p0: P(246, 548), c: P(352, 380), p1: P(338, 176), count: 14, size: 1.2, seed: 8 },
  ],
  flowers: [
    { kind: "eucalyptus", p0: P(300, 540), c: P(340, 360), p1: P(330, 150), count: 6, size: 1.0, seed: 3 },
    { kind: "olive", p0: P(70, 540), c: P(40, 420), p1: P(86, 270), count: 7, size: 1.0, seed: 6 },
  ],
  mixed: [
    { kind: "olive", p0: P(80, 540), c: P(40, 300), p1: P(230, 70), count: 12, size: 1.35, seed: 13 },
    { kind: "eucalyptus", p0: P(340, 540), c: P(360, 360), p1: P(290, 200), count: 6, size: 1.1, seed: 2 },
    { kind: "fern", p0: P(200, 560), c: P(230, 420), p1: P(160, 330), count: 10, size: 1.0, seed: 17 },
  ],
};

const FLOWERS = [
  { cx: 170, cy: 200, r: 74, seed: 3 },
  { cx: 268, cy: 318, r: 54, seed: 5 },
  { cx: 126, cy: 372, r: 44, seed: 9 },
];

/** Traço puro (sem fundo). Herda `currentColor`. Use como ornamento sobre qualquer fundo. */
export function BotanicalStrokes({ variant }: { variant: PlateVariant }) {
  const arts = COMPOSITIONS[variant].map((spec) => branch(spec));
  return (
    <g fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round">
      {arts.map((a, i) => (
        <g key={i}>
          <path d={a.stem} strokeWidth="1.6" />
          <path d={a.leaves} fill="currentColor" fillOpacity="0.1" />
          <path d={a.ribs} strokeWidth="0.9" opacity="0.7" />
        </g>
      ))}
      {variant === "flowers" &&
        FLOWERS.map((f, i) => {
          const r = rosette(f.cx, f.cy, f.r, f.seed);
          return (
            <g key={i}>
              <path d={`M${f.cx} ${f.cy + f.r * 0.5}Q${f.cx + (i % 2 ? 24 : -24)} ${f.cy + 150} ${f.cx + (i - 1) * 14} 540`} strokeWidth="1.6" />
              <path d={r.petals} fill="currentColor" fillOpacity="0.1" />
              <path d={r.center} fill="currentColor" fillOpacity="0.4" />
            </g>
          );
        })}
    </g>
  );
}

type PlateProps = {
  variant?: PlateVariant;
  tone?: PlateTone;
  className?: string;
};

/**
 * "Placa de herbário": ilustração botânica sobre fundo tonal, com o arco da marca.
 * Preenche o contêiner pai (position: relative) e recorta com `slice`.
 */
export function BotanicalPlate({ variant = "olive", tone = "light", className = "" }: PlateProps) {
  const t = TONES[tone];
  return (
    <svg
      viewBox="0 0 400 500"
      preserveAspectRatio="xMidYMid slice"
      className={`absolute inset-0 h-full w-full ${className}`}
      aria-hidden="true"
      focusable="false"
    >
      <rect width="400" height="500" fill={t.bg} />
      <path d={ARCH_PATH} fill="none" stroke={t.soft} strokeOpacity="0.28" strokeWidth="1" />
      <g style={{ color: t.ink }}>
        <BotanicalStrokes variant={variant} />
      </g>
    </svg>
  );
}

/** Três janelas em arco lado a lado — a "estufa" — para molduras largas (16:9, 21:9). */
const WIDE_ARCHES = [220, 600, 980];
const WIDE_BRANCHES: BranchSpec[] = [
  { kind: "olive", p0: P(150, 560), c: P(100, 330), p1: P(262, 80), count: 12, size: 1.6, seed: 11 },
  { kind: "olive", p0: P(300, 560), c: P(330, 440), p1: P(330, 330), count: 5, size: 1.0, seed: 5 },
  { kind: "eucalyptus", p0: P(650, 560), c: P(710, 330), p1: P(560, 70), count: 8, size: 1.7, seed: 9 },
  { kind: "eucalyptus", p0: P(540, 560), c: P(520, 470), p1: P(480, 390), count: 4, size: 1.0, seed: 4 },
  { kind: "fern", p0: P(940, 560), c: P(870, 330), p1: P(1010, 70), count: 16, size: 1.7, seed: 21 },
  { kind: "fern", p0: P(1070, 560), c: P(1110, 450), p1: P(1100, 340), count: 7, size: 1.0, seed: 8 },
];

export function BotanicalPlateWide({ tone = "sand", className = "" }: { tone?: PlateTone; className?: string }) {
  const t = TONES[tone];
  const arts = WIDE_BRANCHES.map((spec) => branch(spec));
  return (
    <svg
      viewBox="0 0 1200 520"
      preserveAspectRatio="xMidYMid slice"
      className={`absolute inset-0 h-full w-full ${className}`}
      aria-hidden="true"
      focusable="false"
    >
      <rect width="1200" height="520" fill={t.bg} />
      {WIDE_ARCHES.map((c) => (
        <path
          key={c}
          d={`M${c - 135} 520V260A135 135 0 0 1 ${c + 135} 260V520`}
          fill="none"
          stroke={t.soft}
          strokeOpacity="0.3"
          strokeWidth="1.2"
        />
      ))}
      <g
        style={{ color: t.ink }}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {arts.map((a, i) => (
          <g key={i}>
            <path d={a.stem} strokeWidth="1.8" />
            <path d={a.leaves} fill="currentColor" fillOpacity="0.1" />
            <path d={a.ribs} strokeWidth="1" opacity="0.7" />
          </g>
        ))}
      </g>
    </svg>
  );
}

/** Ornamento solto (sem fundo), para decorar seções. */
export function BotanicalOrnament({
  variant = "olive",
  className = "",
}: {
  variant?: PlateVariant;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 400 560"
      className={className}
      aria-hidden="true"
      focusable="false"
      style={{ overflow: "visible" }}
    >
      <BotanicalStrokes variant={variant} />
    </svg>
  );
}

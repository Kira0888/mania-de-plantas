import { site } from "@/content/site";
import { waLink } from "@/lib/whatsapp";
import { ArrowIcon, WhatsAppIcon } from "./icons";

type Variant = "primary" | "light" | "outline";
type Size = "md" | "lg";

const VARIANT: Record<Variant, string> = {
  primary: "bg-floresta text-linho hover:bg-mata",
  light: "bg-linho text-mata hover:bg-papel",
  outline: "border border-current/40 text-current hover:border-current",
};

const SIZE: Record<Size, string> = {
  md: "h-11 px-5 text-[0.9rem]",
  lg: "h-14 px-7 text-[0.98rem]",
};

type Props = {
  message?: string;
  label?: string;
  variant?: Variant;
  size?: Size;
  className?: string;
  /** mostra a seta que desliza no hover */
  arrow?: boolean;
};

/**
 * CTA oficial. Sempre o mesmo rótulo, sempre a mesma forma.
 * O ícone é que indica o canal — a cor do botão é da marca, não do WhatsApp.
 */
export function WhatsAppButton({
  message,
  label = site.whatsapp.cta,
  variant = "primary",
  size = "lg",
  className = "",
  arrow = true,
}: Props) {
  return (
    <a
      href={waLink(message)}
      target="_blank"
      rel="noopener noreferrer"
      className={`group inline-flex items-center justify-center gap-3 rounded-full font-medium tracking-[0.005em] whitespace-nowrap transition-colors duration-500 ${VARIANT[variant]} ${SIZE[size]} ${className}`}
    >
      <WhatsAppIcon className="h-[1.15em] w-[1.15em] shrink-0" />
      <span>{label}</span>
      {arrow && (
        <ArrowIcon className="h-[1.1em] w-[1.1em] shrink-0 -translate-x-1 opacity-60 transition-[transform,opacity] duration-500 group-hover:translate-x-0 group-hover:opacity-100" />
      )}
      <span className="sr-only"> (abre o WhatsApp em nova aba)</span>
    </a>
  );
}

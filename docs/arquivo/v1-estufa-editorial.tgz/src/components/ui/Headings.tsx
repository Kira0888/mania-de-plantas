import type { ReactNode } from "react";
import { Reveal } from "../motion/Reveal";

export function Eyebrow({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <p className={`eyebrow inline-flex items-center gap-4 ${className}`}>
      <span aria-hidden="true" className="h-px w-10 bg-current opacity-40" />
      {children}
    </p>
  );
}

type TitleProps = {
  title: { before: string; em: string; after: string };
  onDark?: boolean;
  className?: string;
};

/** Título de seção: uma única expressão em itálico (assinatura tipográfica). */
export function SectionTitle({ title, onDark = false, className = "" }: TitleProps) {
  return (
    <Reveal as="h2" className={`t-display text-display-l text-balance ${className}`}>
      {title.before}
      <span className={`em-accent ${onDark ? "text-petala" : "text-musgo"}`}>{title.em}</span>
      {title.after}
    </Reveal>
  );
}

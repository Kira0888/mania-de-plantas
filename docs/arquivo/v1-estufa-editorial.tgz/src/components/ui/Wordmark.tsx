import { site } from "@/content/site";

/** Marca gráfica: o arco de estufa com um ramo dentro. */
export function Mark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 40" fill="none" className={className} aria-hidden="true">
      <path d="M3.5 38.5V16a12.5 12.5 0 0 1 25 0v22.5Z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M16 36V17" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M16 30c-5.2-.6-7.6-3.6-7.6-8 4.6.2 7.6 3.2 7.6 8Z" fill="currentColor" fillOpacity="0.9" />
      <path d="M16 24c5-.6 7.4-3.4 7.4-7.6-4.4.2-7.4 3-7.4 7.6Z" fill="currentColor" fillOpacity="0.9" />
    </svg>
  );
}

export function Wordmark({ invert = false, className = "" }: { invert?: boolean; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <Mark className={`h-9 w-auto ${invert ? "text-petala" : "text-floresta"}`} />
      <span className="t-display text-[1.4rem] leading-none tracking-[-0.012em]">
        <span className="sr-only">{site.name}</span>
        <span aria-hidden="true">
          Mania <span className={`em-accent ${invert ? "text-salvia" : "text-musgo"}`}>de Plantas</span>
        </span>
      </span>
    </span>
  );
}

import { encomendas, site } from "@/content/site";
import { OrderPlanner } from "../OrderPlanner";
import { Reveal, Stagger, StaggerItem } from "../motion/Reveal";
import { BotanicalOrnament } from "../ui/Botanical";
import { Eyebrow, SectionTitle } from "../ui/Headings";

export function Encomendas() {
  const steps = encomendas.steps.map((s) =>
    s.n === "3" && !site.delivers ? { ...s, body: "Alinhamos a data e a retirada na loja." } : s,
  );

  return (
    <section
      id="encomendas"
      aria-labelledby="encomendas-titulo"
      className="on-dark relative overflow-x-clip bg-mata py-24 text-linho lg:py-40"
    >
      <BotanicalOrnament
        variant="eucalyptus"
        className="pointer-events-none absolute -top-28 right-6 hidden h-[30rem] w-auto rotate-[168deg] text-salvia/[0.1] xl:block"
      />

      <div className="wrap relative grid gap-16 lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-5">
          <Reveal>
            <Eyebrow className="text-salvia">{encomendas.eyebrow}</Eyebrow>
          </Reveal>
          <div id="encomendas-titulo" className="mt-7">
            <SectionTitle title={encomendas.title} onDark />
          </div>
          <Reveal delay={0.15} className="mt-8">
            <p className="max-w-md text-lead text-salvia">{encomendas.lead}</p>
          </Reveal>

          <Stagger as="ol" className="mt-14">
            {steps.map((s) => (
              <StaggerItem
                as="li"
                key={s.n}
                className="grid list-none grid-cols-[3.2rem_1fr] gap-x-4 border-t border-salvia/25 py-7"
              >
                <span className="t-display text-3xl text-petala">{s.n}</span>
                <div>
                  <h3 className="t-display text-[1.45rem] leading-tight">{s.title}</h3>
                  <p className="mt-2 text-[0.95rem] leading-relaxed text-salvia">{s.body}</p>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>

        <Reveal className="lg:col-span-6 lg:col-start-7 lg:pt-6" delay={0.1}>
          <OrderPlanner />
        </Reveal>
      </div>
    </section>
  );
}

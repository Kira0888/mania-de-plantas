import type { ReactNode } from "react";
import { site, visita } from "@/content/site";
import { waLink } from "@/lib/whatsapp";
import { Reveal } from "../motion/Reveal";
import { Eyebrow, SectionTitle } from "../ui/Headings";
import { ArrowIcon } from "../ui/icons";
import { Photo } from "../ui/Photo";
import { WhatsAppButton } from "../ui/WhatsAppButton";

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="grid gap-1 border-t border-mata/15 py-5 sm:grid-cols-[9rem_1fr] sm:gap-6">
      <dt className="eyebrow pt-1.5 text-tinta">{label}</dt>
      <dd className="text-[1.05rem]">{children}</dd>
    </div>
  );
}

export function Visita() {
  return (
    <section id="visita" aria-labelledby="visita-titulo" className="py-24 lg:py-40">
      <div className="wrap">
        <Reveal y={30}>
          <Photo
            name={visita.photo.name}
            alt={visita.photo.alt}
            shape="rect"
            ratio="pano"
            sizes="(min-width: 1440px) 1312px, 92vw"
            plate="mixed"
            tone="sand"
            className="max-h-[38rem]"
            zoom={false}
          />
        </Reveal>

        <div className="mt-14 grid gap-14 lg:mt-24 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-6">
            <Reveal>
              <Eyebrow className="text-musgo">{visita.eyebrow}</Eyebrow>
            </Reveal>
            <div id="visita-titulo" className="mt-7">
              <SectionTitle title={visita.title} />
            </div>
            <Reveal delay={0.15} className="mt-8">
              <p className="max-w-md text-lead text-tinta">{visita.lead}</p>
            </Reveal>
          </div>

          <Reveal delay={0.1} className="lg:col-span-5 lg:col-start-8 lg:pt-12">
            <dl>
              <Row label="WhatsApp">
                <a
                  href={waLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="link-draw font-medium text-floresta"
                >
                  {site.whatsapp.display}
                </a>
              </Row>
              {site.address && (
                <Row label="Endereço">
                  {site.mapsUrl ? (
                    <a
                      href={site.mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="link-draw font-medium text-floresta"
                    >
                      {site.address}
                      <ArrowIcon className="h-4 w-4" />
                    </a>
                  ) : (
                    site.address
                  )}
                </Row>
              )}
              {site.hours && (
                <Row label="Horário">
                  <ul>
                    {site.hours.map((h) => (
                      <li key={h}>{h}</li>
                    ))}
                  </ul>
                </Row>
              )}
              {site.instagram && (
                <Row label="Instagram">
                  <a
                    href={site.instagram.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="link-draw font-medium text-floresta"
                  >
                    {site.instagram.handle}
                  </a>
                </Row>
              )}
              <div className="border-t border-mata/15 pt-8">
                <WhatsAppButton variant="primary" size="lg" message="Olá, Mania de Plantas! Quero combinar uma visita." label="Combinar uma visita" />
              </div>
            </dl>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

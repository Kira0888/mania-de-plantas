import { cuidados } from "@/content/site";
import { waLink } from "@/lib/whatsapp";
import { Reveal, Stagger, StaggerItem } from "../motion/Reveal";
import { Eyebrow, SectionTitle } from "../ui/Headings";
import { ArrowIcon, DropIcon, PotIcon, SunIcon } from "../ui/icons";

const ICONS = { sun: SunIcon, drop: DropIcon, pot: PotIcon } as const;

export function Cuidados() {
  return (
    <section id="cuidados" aria-labelledby="cuidados-titulo" className="bg-areia py-24 lg:py-40">
      <div className="wrap">
        <header className="grid gap-8 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <Reveal>
              <Eyebrow className="text-musgo">{cuidados.eyebrow}</Eyebrow>
            </Reveal>
            <div id="cuidados-titulo" className="mt-7">
              <SectionTitle title={cuidados.title} />
            </div>
          </div>
          <Reveal delay={0.15} className="lg:col-span-4 lg:col-start-9">
            <p className="text-lead text-tinta">{cuidados.lead}</p>
          </Reveal>
        </header>

        <Stagger
          as="ul"
          className="mt-16 grid border-t border-mata/15 md:grid-cols-3 md:divide-x md:divide-mata/15 lg:mt-24"
        >
          {cuidados.items.map((item) => {
            const Icon = ICONS[item.icon];
            return (
              <StaggerItem
                as="li"
                key={item.title}
                className="list-none border-b border-mata/15 px-0 py-10 md:border-b-0 md:px-8 md:py-12 first:md:pl-0 last:md:pr-0"
              >
                <Icon className="h-12 w-12 text-musgo" />
                <p className="eyebrow mt-8 text-tinta">{item.title}</p>
                <h3 className="t-display text-display-m mt-3">{item.question}</h3>
                <p className="mt-4 max-w-sm text-[0.97rem] leading-relaxed text-tinta">{item.body}</p>
              </StaggerItem>
            );
          })}
        </Stagger>

        <Reveal className="mt-12 flex justify-start lg:mt-16">
          <a
            href={waLink(cuidados.cta.message)}
            target="_blank"
            rel="noopener noreferrer"
            className="link-draw text-[1rem] font-medium text-floresta"
          >
            {cuidados.cta.label}
            <ArrowIcon className="h-4 w-4" />
            <span className="sr-only"> (abre em nova aba)</span>
          </a>
        </Reveal>
      </div>
    </section>
  );
}

import { avaliacoes, site } from "@/content/site";
import { visibleReviews } from "@/content/reviews";
import { Reveal, Stagger, StaggerItem } from "../motion/Reveal";
import { Eyebrow, SectionTitle } from "../ui/Headings";
import { ArrowIcon, StarIcon } from "../ui/icons";
import { WhatsAppButton } from "../ui/WhatsAppButton";

export function Avaliacoes() {
  const list = visibleReviews();
  const hasReviews = list.length > 0;

  return (
    <section id="avaliacoes" aria-labelledby="avaliacoes-titulo" className="py-24 lg:py-40">
      <div className="wrap grid gap-16 lg:grid-cols-12 lg:gap-8">
        {/* Nota — o número é o herói */}
        <div className="lg:col-span-5">
          <Reveal>
            <Eyebrow className="text-musgo">{avaliacoes.eyebrow}</Eyebrow>
          </Reveal>

          <Reveal y={36} className="mt-6">
            <p
              className="t-display leading-[0.8] text-floresta"
              style={{ fontSize: "clamp(7.5rem, 3.5rem + 17vw, 17rem)", letterSpacing: "-0.05em" }}
              aria-label={`Nota ${site.rating.score} de 5`}
            >
              {site.rating.score}
            </p>
          </Reveal>

          <Reveal delay={0.1} className="mt-14 flex items-center gap-4">
            <span className="flex gap-1 text-peonia" aria-hidden="true">
              {Array.from({ length: 5 }).map((_, i) => (
                <StarIcon key={i} className="h-5 w-5" />
              ))}
            </span>
            <span className="eyebrow text-tinta">{site.rating.caption}</span>
          </Reveal>

          {site.googleReviewsUrl && (
            <Reveal delay={0.2} className="mt-8">
              <a
                href={site.googleReviewsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="link-draw text-[0.95rem] font-medium text-floresta"
              >
                {avaliacoes.seeAll}
                <ArrowIcon className="h-4 w-4" />
              </a>
            </Reveal>
          )}
        </div>

        {/* Depoimentos reais (ou convite, se ainda não houver) */}
        <div className="lg:col-span-6 lg:col-start-7 lg:pt-14">
          <div id="avaliacoes-titulo">
            <SectionTitle title={avaliacoes.title} />
          </div>

          {hasReviews ? (
            <Stagger as="div" className="mt-12">
              {list.map((r, i) => (
                <StaggerItem key={i}>
                  <figure className="border-t border-mata/15 py-8">
                    <blockquote className="t-display text-display-m text-pretty">
                      <span aria-hidden="true" className="text-peonia">
                        “
                      </span>
                      {r.quote}
                      <span aria-hidden="true" className="text-peonia">
                        ”
                      </span>
                    </blockquote>
                    <figcaption className="eyebrow mt-5 flex flex-wrap items-center gap-x-3 gap-y-2 text-tinta">
                      <span>{r.author}</span>
                      <span aria-hidden="true" className="opacity-40">
                        ·
                      </span>
                      <span>{r.source}</span>
                      {!r.verified && (
                        <span className="rounded-full border border-dashed border-peonia px-3 py-1 text-[0.62rem] text-peonia">
                          modelo — só aparece em desenvolvimento
                        </span>
                      )}
                    </figcaption>
                  </figure>
                </StaggerItem>
              ))}
            </Stagger>
          ) : (
            <Reveal delay={0.1} className="mt-10 border-t border-mata/15 pt-8">
              <p className="max-w-lg text-lead text-tinta">{avaliacoes.emptyText}</p>
              <div className="mt-8 flex flex-wrap items-center gap-6">
                <WhatsAppButton variant="primary" size="md" label="Conversar no WhatsApp" arrow={false} />
              </div>
            </Reveal>
          )}
        </div>
      </div>
    </section>
  );
}

import Image from "next/image";
import { ctaFinal } from "@/content/site";
import { resolvePhoto } from "@/lib/photos";
import { Reveal } from "../motion/Reveal";
import { RevealLines } from "../motion/RevealLines";
import { BotanicalOrnament } from "../ui/Botanical";
import { WhatsAppButton } from "../ui/WhatsAppButton";

export function CtaFinal() {
  const bg = resolvePhoto("cta-fundo");

  return (
    <section
      id="encomendar"
      aria-labelledby="cta-titulo"
      className="on-dark relative isolate overflow-hidden bg-mata py-28 text-linho lg:py-44"
    >
      {bg ? (
        <>
          <Image src={bg} alt="" fill sizes="100vw" className="-z-10 object-cover opacity-40" />
          <div aria-hidden="true" className="absolute inset-0 -z-10 bg-mata/60" />
        </>
      ) : (
        <BotanicalOrnament
          variant="fern"
          className="pointer-events-none absolute top-1/2 -right-16 -z-10 h-[46rem] w-auto -translate-y-1/2 text-salvia/[0.07] sm:right-0 sm:text-salvia/[0.13] lg:right-16"
        />
      )}

      <div className="wrap">
        <div id="cta-titulo">
          <RevealLines
            as="h2"
            lines={ctaFinal.titleLines}
            className="t-display text-display-xl"
            emClassName="text-petala"
          />
        </div>

        <Reveal delay={0.2} className="mt-10 max-w-lg">
          <p className="text-lead text-salvia">{ctaFinal.lead}</p>
        </Reveal>

        <Reveal delay={0.3} className="mt-12">
          <WhatsAppButton variant="light" size="lg" message={ctaFinal.message} />
        </Reveal>
      </div>
    </section>
  );
}

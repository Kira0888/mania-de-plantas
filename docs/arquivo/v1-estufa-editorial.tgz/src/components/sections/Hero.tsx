import { hero, site } from "@/content/site";
import { ParallaxFrame } from "../motion/ParallaxFrame";
import { Reveal } from "../motion/Reveal";
import { RevealLines } from "../motion/RevealLines";
import { Eyebrow } from "../ui/Headings";
import { PhotoFill } from "../ui/Photo";
import { StarIcon } from "../ui/icons";
import { WhatsAppButton } from "../ui/WhatsAppButton";

/** Selo da nota: anel de texto girando devagar (CSS/compositor) + 5,0 fixo no centro. */
function RatingSeal() {
  return (
    <div className="relative h-[8.5rem] w-[8.5rem] sm:h-[9.5rem] sm:w-[9.5rem]">
      <svg viewBox="0 0 160 160" className="selo-gira absolute inset-0 h-full w-full" aria-hidden="true">
        <defs>
          <path id="seal-ring" d="M80 80m-60 0a60 60 0 1 1 120 0a60 60 0 1 1-120 0" />
        </defs>
        <circle cx="80" cy="80" r="79" fill="#2a4a36" />
        <circle cx="80" cy="80" r="74" fill="none" stroke="#b7c4ae" strokeOpacity="0.35" strokeWidth="0.8" />
        <text
          fill="#ebd3c8"
          fontSize="9.6"
          letterSpacing="3.1"
          style={{ fontFamily: "var(--font-hanken), sans-serif", fontWeight: 500 }}
        >
          <textPath href="#seal-ring">NOTA MÁXIMA · AVALIAÇÕES REAIS · DE CLIENTES ·</textPath>
        </text>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-linho">
        <span className="t-display text-[2.6rem] leading-none sm:text-[2.9rem]">{site.rating.score}</span>
        <span className="mt-1.5 flex gap-0.5 text-petala" aria-hidden="true">
          {Array.from({ length: 5 }).map((_, i) => (
            <StarIcon key={i} className="h-2.5 w-2.5" />
          ))}
        </span>
      </div>
      <p className="sr-only">
        {site.rating.caption}: {site.rating.score} de 5.
      </p>
    </div>
  );
}

export function Hero() {
  return (
    <section id="inicio" className="relative overflow-x-clip pt-6 pb-20 lg:pt-10 lg:pb-32">
      <div className="wrap grid items-center gap-16 lg:grid-cols-12 lg:gap-8">
        {/* Texto */}
        <div className="lg:col-span-7 lg:pr-10 xl:pr-20">
          <Reveal delay={0.05}>
            <Eyebrow className="text-musgo">{hero.eyebrow}</Eyebrow>
          </Reveal>

          <RevealLines
            lines={hero.titleLines}
            onMount
            className="t-display text-display-xl mt-7 text-mata"
            emClassName="text-musgo"
          />

          <Reveal delay={0.55} className="mt-9">
            <p className="max-w-[35rem] text-lead text-tinta">{hero.lead}</p>
          </Reveal>

          <Reveal delay={0.7} className="mt-10 flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:gap-9">
            <WhatsAppButton variant="primary" size="lg" />
            <a href={hero.secondaryCta.href} className="link-draw text-[0.95rem] font-medium">
              {hero.secondaryCta.label}
            </a>
          </Reveal>
        </div>

        {/* Imagem: arco + detalhe + selo */}
        <div className="relative lg:col-span-5">
          <ParallaxFrame className="aspect-[4/5] w-full rounded-t-full bg-neblina">
            <PhotoFill
              name="hero-arco"
              alt="Plantas ornamentais em vasos de cerâmica junto a uma janela em arco, com a luz da manhã"
              sizes="(min-width: 1024px) 40vw, 92vw"
              priority
              plate="olive"
              tone="light"
            />
          </ParallaxFrame>

          {/* Detalhe circular sobreposto */}
          <Reveal delay={0.9} className="absolute -bottom-8 -left-2 w-[36%] sm:-left-6 lg:-bottom-10 lg:-left-14">
            <div className="foto-zoom relative aspect-square overflow-hidden rounded-full border-[7px] border-linho bg-areia isolate">
              <PhotoFill
                name="hero-detalhe"
                alt="Detalhe de uma folha verde com gotas de água"
                sizes="(min-width: 1024px) 15vw, 34vw"
                plate="fern"
                tone="sand"
              />
            </div>
          </Reveal>

          {/* Selo da nota */}
          <Reveal delay={1.05} className="absolute -top-5 -right-1 sm:-top-7 sm:-right-4 lg:-top-8 lg:-right-8">
            <RatingSeal />
          </Reveal>

          <p className="eyebrow mt-5 text-right text-tinta lg:mt-6">
            <span className="opacity-60">Fig. 01 — </span>
            {hero.caption}
          </p>
        </div>
      </div>
    </section>
  );
}

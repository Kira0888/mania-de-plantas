import { manifesto } from "@/content/site";
import { Reveal, Stagger, StaggerItem } from "../motion/Reveal";
import { BotanicalOrnament } from "../ui/Botanical";
import { Eyebrow } from "../ui/Headings";
import { Photo } from "../ui/Photo";

export function Manifesto() {
  return (
    <section aria-label="Manifesto" className="relative overflow-x-clip border-t border-mata/10 py-24 lg:py-40">
      <div className="wrap grid gap-16 lg:grid-cols-12 lg:gap-8">
        {/* Foto de ofício */}
        <Reveal className="relative lg:col-span-4 lg:col-start-1">
          <Photo
            name="atelie-maos"
            alt="Mãos de uma florista amarrando um buquê com barbante natural em uma bancada de madeira"
            shape="rect"
            ratio="4/5"
            sizes="(min-width: 1024px) 30vw, 88vw"
            plate="flowers"
            tone="rose"
          />
          <p className="eyebrow mt-4 text-tinta">
            <span className="opacity-60">Fig. 02 — </span>Feito à mão, um por um.
          </p>
        </Reveal>

        {/* Texto */}
        <div className="relative lg:col-span-7 lg:col-start-6 lg:pt-10">
          <Reveal>
            <Eyebrow className="text-musgo">{manifesto.eyebrow}</Eyebrow>
          </Reveal>

          <Reveal as="p" delay={0.1} className="t-display text-display-l mt-8 text-balance" y={30}>
            {manifesto.text.map((run, i) =>
              "em" in run && run.em ? (
                <span key={i} className="em-accent text-musgo">
                  {run.t}
                </span>
              ) : (
                <span key={i}>{run.t}</span>
              ),
            )}
          </Reveal>

          <Stagger as="ul" className="mt-16 grid gap-x-10 gap-y-10 border-t border-mata/15 pt-10 sm:grid-cols-3">
            {manifesto.pillars.map((p) => (
              <StaggerItem as="li" key={p.title} className="list-none">
                <h3 className="t-display text-display-m">{p.title}</h3>
                <p className="mt-3 text-[0.95rem] leading-relaxed text-tinta">{p.body}</p>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </div>

      {/* ornamento discreto */}
      <BotanicalOrnament
        variant="olive"
        className="pointer-events-none absolute -right-36 -bottom-32 hidden h-[34rem] w-auto rotate-12 text-floresta/[0.07] xl:block"
      />
    </section>
  );
}

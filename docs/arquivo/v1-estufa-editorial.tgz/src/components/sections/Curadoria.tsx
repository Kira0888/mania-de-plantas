import { curadoria } from "@/content/site";
import { waLink } from "@/lib/whatsapp";
import { Reveal } from "../motion/Reveal";
import { Eyebrow, SectionTitle } from "../ui/Headings";
import { ArrowIcon } from "../ui/icons";
import { Photo, type Ratio, type Shape } from "../ui/Photo";

/**
 * Composição assimétrica de 4 coleções (desktop): as fotos se desencontram de propósito,
 * como numa página de revista. No mobile vira uma coluna única, sem offset.
 */
const LAYOUT: { wrap: string; shape: Shape; ratio: Ratio; sizes: string }[] = [
  { wrap: "lg:col-span-7", shape: "arch", ratio: "4/5", sizes: "(min-width: 1024px) 50vw, 92vw" },
  { wrap: "lg:col-span-4 lg:col-start-9 lg:mt-44", shape: "rect", ratio: "1/1", sizes: "(min-width: 1024px) 30vw, 92vw" },
  { wrap: "lg:col-span-5 lg:col-start-2 lg:-mt-6", shape: "rect", ratio: "1/1", sizes: "(min-width: 1024px) 36vw, 92vw" },
  { wrap: "lg:col-span-6 lg:col-start-7 lg:mt-24", shape: "arch", ratio: "4/5", sizes: "(min-width: 1024px) 44vw, 92vw" },
];

export function Curadoria() {
  return (
    <section id="curadoria" aria-labelledby="curadoria-titulo" className="bg-areia py-24 lg:py-40">
      <div className="wrap">
        <header className="grid gap-8 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <Reveal>
              <Eyebrow className="text-musgo">{curadoria.eyebrow}</Eyebrow>
            </Reveal>
            <div id="curadoria-titulo" className="mt-7">
              <SectionTitle title={curadoria.title} />
            </div>
          </div>
          <Reveal delay={0.15} className="lg:col-span-4 lg:col-start-9">
            <p className="text-lead text-tinta">{curadoria.lead}</p>
          </Reveal>
        </header>

        <div className="mt-16 grid gap-x-8 gap-y-20 lg:mt-24 lg:grid-cols-12 lg:items-start lg:gap-y-16">
          {curadoria.items.map((item, i) => {
            const l = LAYOUT[i];
            return (
              <Reveal key={item.id} className={`group ${l.wrap}`} delay={i % 2 ? 0.1 : 0}>
                <article>
                  <Photo
                    name={item.photo}
                    alt={item.alt}
                    shape={l.shape}
                    ratio={l.ratio}
                    sizes={l.sizes}
                    plate={item.plate}
                    tone={item.tone}
                  />
                  <div className="mt-6 grid grid-cols-[auto_1fr] gap-x-5 border-t border-mata/15 pt-5">
                    <span className="eyebrow pt-2 text-musgo">{item.n}</span>
                    <div>
                      <h3 className="t-display text-display-m">{item.title}</h3>
                      <p className="mt-3 max-w-md text-[0.97rem] leading-relaxed text-tinta">{item.body}</p>
                      <a
                        href={waLink(item.message)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="link-draw mt-5 text-[0.92rem] font-medium text-floresta"
                      >
                        Pedir pelo WhatsApp
                        <ArrowIcon className="h-4 w-4 transition-transform duration-500 group-hover:translate-x-1" />
                        <span className="sr-only"> — {item.title} (abre em nova aba)</span>
                      </a>
                    </div>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

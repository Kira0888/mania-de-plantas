import { footer, nav, site } from "@/content/site";
import { waLink } from "@/lib/whatsapp";
import { Wordmark } from "./ui/Wordmark";

export function Footer() {
  return (
    <footer className="border-t border-mata/10 pt-20 pb-28 lg:pb-12">
      <div className="wrap">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-5">
            <Wordmark />
            <p className="mt-6 max-w-xs text-[0.95rem] leading-relaxed text-tinta">{footer.note}</p>
          </div>

          <nav aria-label="Rodapé" className="lg:col-span-3 lg:col-start-7">
            <p className="eyebrow text-tinta">Navegar</p>
            <ul className="mt-5 space-y-3">
              {nav.map((item) => (
                <li key={item.href}>
                  <a href={item.href} className="link-draw text-[0.97rem]">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="lg:col-span-3">
            <p className="eyebrow text-tinta">Contato</p>
            <ul className="mt-5 space-y-3 text-[0.97rem]">
              <li>
                <a href={waLink()} target="_blank" rel="noopener noreferrer" className="link-draw">
                  WhatsApp {site.whatsapp.display}
                  <span className="sr-only"> (abre em nova aba)</span>
                </a>
              </li>
              {site.instagram && (
                <li>
                  <a href={site.instagram.url} target="_blank" rel="noopener noreferrer" className="link-draw">
                    {site.instagram.handle}
                  </a>
                </li>
              )}
              {site.address && <li className="text-tinta">{site.address}</li>}
            </ul>
          </div>
        </div>

        <div className="mt-16 flex flex-col justify-between gap-3 border-t border-mata/10 pt-6 text-[0.8rem] text-tinta sm:flex-row">
          <p>
            © {new Date().getFullYear()} {site.name} · {site.descriptor}
          </p>
          <p>{site.tagline}</p>
        </div>
      </div>
    </footer>
  );
}

# Fotografias

Coloque aqui as fotos reais da loja. O site detecta os arquivos automaticamente pelo **nome** (extensões aceitas: `.avif`, `.webp`, `.jpg`, `.jpeg`, `.png`).

| Nome do arquivo | Proporção | Conteúdo sugerido |
|---|---|---|
| `hero-arco` | 4:5 vertical | Plantas junto a uma janela, luz natural, mãos de quem atende |
| `hero-detalhe` | 1:1 | Folha em detalhe, gotas d'água |
| `atelie-maos` | 4:5 vertical | Mãos montando um buquê na bancada |
| `curadoria-ornamentais` | 4:5 vertical | Prateleira de plantas ornamentais |
| `curadoria-arranjos` | 1:1 | Arranjo vivo (suculentas, samambaia, musgo) |
| `curadoria-variedades` | 1:1 | Variedades botânicas na bancada |
| `curadoria-flores` | 4:5 vertical | Buquê feito sob medida |
| `loja-interior` | 16:9 horizontal | Panorâmica acolhedora da loja |
| `cta-fundo` | 21:9 horizontal | Folhagem em sombra (fundo escuro, opcional) |

Dicas: mínimo 1600 px no lado maior · sem texto, logotipo ou etiqueta de preço na imagem · luz natural lateral.
Prompts completos e direção de fotografia: `docs/DIRECAO-DE-MARCA.md`, seções 6 e 8.
